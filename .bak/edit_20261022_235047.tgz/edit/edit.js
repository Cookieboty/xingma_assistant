const { request } = require('../../../utils/request');

function buildDescription(sizeText, description) {
  const size = (sizeText || '').trim();
  let desc = (description || '').trim();
  // 去掉旧尺码行再重写
  desc = desc.replace(/^尺码[：:].+$/m, '').trim();
  if (size) desc = desc ? `尺码：${size}\n${desc}` : `尺码：${size}`;
  return desc || null;
}

function parseSizeFromDesc(description) {
  const m = (description || '').match(/尺码[：:]\s*(.+)/);
  return m ? m[1].trim() : '';
}

Page({
  data: {
    id: '',
    styleNo: '',
    name: '',
    material: '',
    description: '',
    sizeText: '',
    levelId: '',
    priceDisplay: 'show',
    status: 'on_sale',
    skus: [{ color: '', price: '' }],
    productLevels: [],
    levelIndex: 0,
    images: [],
    saving: false,
    uploading: false,
  },
  async onLoad(q) {
    await this.loadLevels();
    if (q.id) {
      this.setData({ id: q.id });
      await this.loadProduct(q.id);
    }
  },
  async loadLevels() {
    try {
      const productLevels = await request({ url: '/api/levels/product' });
      const list = productLevels || [];
      this.setData({
        productLevels: list,
        levelId: this.data.levelId || (list[0] && list[0].id) || '',
        levelIndex: 0,
      });
    } catch (e) {
      wx.showToast({ title: e.message || '等级加载失败', icon: 'none' });
    }
  },
  async loadProduct(id) {
    try {
      const p = await request({ url: `/api/products/${id}` });
      const levels = this.data.productLevels;
      let levelIndex = levels.findIndex((l) => l.id === p.levelId);
      if (levelIndex < 0) levelIndex = 0;
      const sizeText = parseSizeFromDesc(p.description);
      let description = p.description || '';
      description = description.replace(/^尺码[：:].+\n?/m, '').trim();
      this.setData({
        styleNo: p.styleNo || '',
        name: p.name || '',
        material: p.material || '',
        description,
        sizeText,
        levelId: p.levelId || '',
        priceDisplay: p.priceDisplay || 'show',
        status: p.status || 'draft',
        skus: (p.skus && p.skus.length)
          ? p.skus.map((s) => ({
              id: s.id,
              color: s.color || '',
              price: s.price != null ? String(s.price) : '',
            }))
          : [{ color: '', price: '' }],
        levelIndex,
        images: (p.images || []).filter((im) => im && im.url),
      });
    } catch (e) {
      wx.showToast({ title: e.message || '加载失败', icon: 'none' });
    }
  },
  previewImage(e) {
    const url = e.currentTarget.dataset.url;
    const urls = (this.data.images || []).map((im) => im.url).filter(Boolean);
    if (!url || !urls.length) return;
    wx.previewImage({ urls, current: url });
  },
  addImages() {
    if (!this.data.id || this.data.uploading) return;
    const MAX = 60;
    const remain = MAX - (this.data.images || []).length;
    if (remain <= 0) {
      wx.showToast({ title: `最多 ${MAX} 张`, icon: 'none' });
      return;
    }
    const count = Math.min(9, remain);
    wx.chooseMedia({
      count,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const paths = (res.tempFiles || []).map((f) => f.tempFilePath).filter(Boolean);
        if (paths.length) this.uploadPaths(paths);
      },
      fail: (err) => {
        // 用户取消不回退；仅当 chooseMedia 不可用时再试 chooseImage
        const msg = (err && (err.errMsg || err.message)) || '';
        if (/cancel/i.test(msg)) return;
        wx.chooseImage({
          count,
          success: (res) => {
            const paths = res.tempFilePaths || [];
            if (paths.length) this.uploadPaths(paths);
          },
        });
      },
    });
  },
  uploadPaths(paths) {
    const app = getApp();
    const baseUrl = app.globalData.baseUrl || '';
    const token = app.globalData.token || wx.getStorageSync('token') || '';
    const tenantId = app.globalData.tenantId || 'tenant_dev_001';
    const id = this.data.id;
    this.setData({ uploading: true });
    wx.showLoading({ title: '上传中' });
    // 一次请求带多文件：wx.uploadFile 单文件，逐张上传后刷新
    (async () => {
      try {
        for (const filePath of paths) {
          await new Promise((resolve, reject) => {
            wx.uploadFile({
              url: `${baseUrl}/api/products/${id}/images`,
              filePath,
              name: 'files',
              header: {
                Authorization: token ? `Bearer ${token}` : '',
                'X-Tenant-Id': tenantId,
                'X-Wx-Appid': app.globalData.appId || 'wx394d23ea099d8a01',
              },
              success: (res) => {
                if (res.statusCode >= 200 && res.statusCode < 300) {
                  try {
                    const body = JSON.parse(res.data);
                    if (body.images) this.setData({ images: body.images.filter((im) => im && im.url) });
                    resolve(body);
                  } catch (e) {
                    reject(new Error('上传响应解析失败'));
                  }
                } else {
                  let msg = `上传失败 ${res.statusCode}`;
                  try { msg = JSON.parse(res.data).message || msg; } catch (e) { /* */ }
                  reject(new Error(typeof msg === 'string' ? msg : JSON.stringify(msg)));
                }
              },
              fail: reject,
            });
          });
        }
        wx.hideLoading();
        wx.showToast({ title: `已添加 ${paths.length} 张`, icon: 'none' });
      } catch (e) {
        wx.hideLoading();
        const msg = (e && (e.message || e.errMsg)) || '上传失败';
        wx.showToast({ title: String(msg).slice(0, 40), icon: 'none', duration: 3000 });
      } finally {
        this.setData({ uploading: false });
      }
    })();
  },
  async removeImage(e) {
    const mediaId = e.currentTarget.dataset.id;
    if (!mediaId || !this.data.id) return;
    const ok = await new Promise((resolve) => {
      wx.showModal({
        title: '删除图片',
        content: '确定从商品中删除这张图？',
        success: (r) => resolve(!!r.confirm),
      });
    });
    if (!ok) return;
    try {
      const p = await request({
        url: `/api/products/${this.data.id}/images/${mediaId}`,
        method: 'DELETE',
        data: {},
      });
      this.setData({ images: (p.images || []).filter((im) => im && im.url) });
    } catch (err) {
      wx.showToast({ title: err.message || '删除失败', icon: 'none' });
    }
  },
  onStyle(e) { this.setData({ styleNo: e.detail.value }); },
  onName(e) { this.setData({ name: e.detail.value }); },
  onMaterial(e) { this.setData({ material: e.detail.value }); },
  onDesc(e) { this.setData({ description: e.detail.value }); },
  onSizeText(e) { this.setData({ sizeText: e.detail.value }); },
  onStatusTap(e) { this.setData({ status: e.currentTarget.dataset.v }); },
  onPriceDisplayTap(e) { this.setData({ priceDisplay: e.currentTarget.dataset.v }); },
  onLevelChange(e) {
    const idx = Number(e.detail.value);
    const level = this.data.productLevels[idx];
    this.setData({ levelIndex: idx, levelId: level ? level.id : '' });
  },
  onSkusChange(e) {
    this.setData({ skus: e.detail.skus || [] });
  },
  buildPayload() {
    const skus = (this.data.skus || [])
      .filter((s) => (s.color || '').trim())
      .map((s) => ({
        color: s.color.trim(),
        size: null,
        price: (s.price || '').trim() || null,
        stock: 0,
        status: 'active',
      }));
    return {
      styleNo: this.data.styleNo.trim(),
      name: this.data.name.trim(),
      material: this.data.material.trim() || null,
      description: buildDescription(this.data.sizeText, this.data.description),
      levelId: this.data.levelId,
      priceDisplay: this.data.priceDisplay,
      status: this.data.status,
      skus,
    };
  },
  async save() {
    if (this.data.saving) return;
    const payload = this.buildPayload();
    if (!payload.styleNo || !payload.name || !payload.levelId) {
      wx.showToast({ title: '请填款号、名称', icon: 'none' });
      return;
    }
    if (!payload.skus.length) {
      wx.showToast({ title: '请至少填写一个颜色', icon: 'none' });
      return;
    }
    this.setData({ saving: true });
    try {
      if (this.data.id) {
        const { skus, ...rest } = payload;
        await request({ url: `/api/products/${this.data.id}`, method: 'PATCH', data: rest });
        const detail = await request({ url: `/api/products/${this.data.id}` });
        for (const s of detail.skus || []) {
          await request({
            url: `/api/products/${this.data.id}/skus/${s.id}`,
            method: 'DELETE',
          }).catch(() => {});
        }
        for (const s of skus) {
          await request({
            url: `/api/products/${this.data.id}/skus`,
            method: 'POST',
            data: s,
          });
        }
      } else {
        await request({ url: '/api/products', method: 'POST', data: payload });
      }
      wx.showToast({ title: '已保存' });
      setTimeout(() => wx.navigateBack(), 500);
    } catch (e) {
      wx.showToast({ title: e.message || '保存失败', icon: 'none' });
    } finally {
      this.setData({ saving: false });
    }
  },
  async copyProduct() {
    if (!this.data.id) return;
    try {
      const res = await request({
        url: `/api/products/${this.data.id}/copy`,
        method: 'POST',
        data: {},
      });
      wx.showToast({ title: '已复制' });
      wx.redirectTo({ url: `/pages/product/edit/edit?id=${res.id}` });
    } catch (e) {
      wx.showToast({ title: e.message || '复制失败', icon: 'none' });
    }
  },
});
