const { request } = require('../../../utils/request');
const { saveUrlsToAlbum } = require('../../../utils/saveAlbum');
const { requestJobSubscribe } = require('../../../utils/profile');

const STEP_NAMES = {
  reference: '选参考图', colors: '选颜色', feature: '商品特征', model: '选模特',
  pose: '动作 / 呈现', scene: '场景 / 背景', count: '张数与尺寸',
};

Page({
  data: {
    id: '', loading: true,
    templates: [], models: [], tpl: null,
    steps: [], stepIdx: -1, stepKey: '', stepNames: STEP_NAMES,
    assets: [], colors: [], feature: '', featureDirty: false,
    sel: { refs: [], colors: [], modelId: '', poses: [], scenes: [], count: 1, sizeId: '' },
    job: null, submitting: false, saving: false,
    savingAlbum: false, albumSelectedCount: 0, albumAllSelected: false, albumSaveLabel: '保存到相册',
  },

  async onLoad(q) {
    this.setData({ id: q.id });
    try {
      const [p, s] = await Promise.all([
        request({ url: '/api/promo/presets' }),
        request({ url: `/api/products/${q.id}/promo/start`, method: 'POST', data: {} }),
      ]);
      this.setData({
        templates: p.templates, models: p.models,
        assets: s.assets.map((a) => Object.assign(a, { checked: false })),
        colors: s.colors.map((c) => ({ name: c, checked: false })),
        feature: s.feature, product: s.product, loading: false,
      });
      if (!s.configured) wx.showToast({ title: '服务端未配置生图密钥', icon: 'none' });
    } catch (e) {
      this.setData({ loading: false });
      wx.showToast({ title: e.message || '加载失败', icon: 'none' });
    }
  },
  onUnload() { clearTimeout(this.timer); },

  // ---- 模板 ----
  pickTemplate(e) {
    const tpl = this.data.templates.find((t) => t.id === e.currentTarget.dataset.id);
    const steps = tpl.steps.filter((s) => !(s === 'model' && tpl.model === 'none'));
    this.setData({
      tpl, steps, stepIdx: 0, stepKey: steps[0], job: null,
      sel: {
        refs: [], colors: [], modelId: tpl.model === 'required' ? (this.data.models[0] || {}).id : '',
        poses: tpl.poses.length ? [tpl.poses[0].id] : [], scenes: tpl.scenes.length ? [tpl.scenes[0].id] : [],
        count: tpl.count.default, sizeId: tpl.defaultSize,
      },
      assets: this.data.assets.map((a) => Object.assign(a, { checked: false })),
      colors: this.data.colors.map((c) => Object.assign(c, { checked: false })),
    });
    this.refreshOptionFlags();
  },
  backToTemplates() { this.setData({ tpl: null, stepIdx: -1, stepKey: '', job: null }); },

  // ---- 步骤 ----
  prev() {
    if (this.data.stepIdx <= 0) return this.backToTemplates();
    const i = this.data.stepIdx - 1;
    this.setData({ stepIdx: i, stepKey: this.data.steps[i] });
  },
  async next() {
    const err = this.validate(this.data.stepKey);
    if (err) return wx.showToast({ title: err, icon: 'none' });
    if (this.data.stepKey === 'feature' && this.data.featureDirty) {
      try {
        await request({ url: `/api/products/${this.data.id}/promo/feature`, method: 'PUT', data: { feature: this.data.feature } });
        this.setData({ featureDirty: false });
      } catch (e) { wx.showToast({ title: '特征保存失败', icon: 'none' }); }
    }
    if (this.data.stepIdx >= this.data.steps.length - 1) return this.submit();
    const i = this.data.stepIdx + 1;
    this.setData({ stepIdx: i, stepKey: this.data.steps[i] });
  },
  validate(k) {
    const { tpl, sel } = this.data;
    if (k === 'reference' && (sel.refs.length < tpl.reference.min || sel.refs.length > tpl.reference.max)) {
      return `请选择 ${tpl.reference.min}-${tpl.reference.max} 张参考图`;
    }
    if (k === 'colors' && sel.colors.length && sel.colors.length !== sel.refs.length) {
      return `已选 ${sel.refs.length} 张图，请选同样数量的颜色（按顺序对应）`;
    }
    if (k === 'model' && tpl.model === 'required' && !sel.modelId) return '请选择模特';
    return '';
  },

  toggleRef(e) {
    const id = e.currentTarget.dataset.id;
    let refs = this.data.sel.refs.slice();
    const i = refs.indexOf(id);
    if (i >= 0) refs.splice(i, 1);
    else {
      if (refs.length >= this.data.tpl.reference.max) return wx.showToast({ title: `最多 ${this.data.tpl.reference.max} 张`, icon: 'none' });
      refs.push(id);
    }
    this.setData({
      'sel.refs': refs,
      assets: this.data.assets.map((a) => Object.assign(a, { checked: refs.indexOf(a.id) >= 0, order: refs.indexOf(a.id) + 1 })),
    });
  },
  previewAsset(e) {
    wx.previewImage({ urls: [e.currentTarget.dataset.url] });
  },
  toggleColor(e) {
    const name = e.currentTarget.dataset.name;
    let cs = this.data.sel.colors.slice();
    const i = cs.indexOf(name);
    if (i >= 0) cs.splice(i, 1); else cs.push(name);
    this.setData({ 'sel.colors': cs, colors: this.data.colors.map((c) => Object.assign(c, { checked: cs.indexOf(c.name) >= 0 })) });
  },
  onFeature(e) { this.setData({ feature: e.detail.value, featureDirty: true }); },
  pickModel(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({ 'sel.modelId': this.data.sel.modelId === id && this.data.tpl.model !== 'required' ? '' : id });
  },
  toggleMulti(e) {
    const { kind, id } = e.currentTarget.dataset; // kind = poses | scenes
    let arr = this.data.sel[kind].slice();
    const i = arr.indexOf(id);
    if (i >= 0) { if (arr.length > 1) arr.splice(i, 1); } else arr.push(id);
    this.setData({ [`sel.${kind}`]: arr });
    this.refreshOptionFlags();
  },
  refreshOptionFlags() {
    const { tpl, sel } = this.data;
    if (!tpl) return;
    this.setData({
      poseOpts: tpl.poses.map((o) => Object.assign({}, o, { on: sel.poses.indexOf(o.id) >= 0 })),
      sceneOpts: tpl.scenes.map((o) => Object.assign({}, o, { on: sel.scenes.indexOf(o.id) >= 0 })),
    });
  },
  countMinus() { if (this.data.sel.count > this.data.tpl.count.min) this.setData({ 'sel.count': this.data.sel.count - 1 }); },
  countPlus() { if (this.data.sel.count < this.data.tpl.count.max) this.setData({ 'sel.count': this.data.sel.count + 1 }); },
  pickSize(e) { this.setData({ 'sel.sizeId': e.currentTarget.dataset.id }); },

  // ---- 提交与进度 ----
  /** 合并轮询结果时保留相册勾选状态 */
  mergeJobAlbumSel(job) {
    const prev = ((this.data.job && this.data.job.items) || []);
    const prevByUrl = {};
    const prevByIdx = {};
    prev.forEach((it, i) => {
      if (it && it.albumSelected) {
        if (it.url) prevByUrl[it.url] = true;
        prevByIdx[i] = true;
      }
    });
    const items = (job.items || []).map((it, i) => Object.assign({}, it, {
      albumSelected: !!(it && it.url && (prevByUrl[it.url] || prevByIdx[i])),
    }));
    return Object.assign({}, job, { items });
  },
  syncAlbumSel(items) {
    const list = items || ((this.data.job && this.data.job.items) || []);
    const withUrl = list.filter((i) => i && i.url);
    const selected = withUrl.filter((i) => i.albumSelected);
    const n = selected.length;
    this.setData({
      albumSelectedCount: n,
      albumAllSelected: withUrl.length > 0 && n === withUrl.length,
      albumSaveLabel: n ? `保存到相册(${n})` : '保存到相册',
    });
  },
  setJobWithAlbum(job) {
    const merged = this.mergeJobAlbumSel(job);
    this.setData({ job: merged });
    this.syncAlbumSel(merged.items);
  },

  async submit() {
    try { await requestJobSubscribe(); } catch (e) { /* ignore */ }
    const { tpl, sel, feature, id } = this.data;
    this.setData({ submitting: true });
    try {
      const job = await request({
        url: `/api/products/${id}/promo/generate`, method: 'POST',
        data: {
          templateId: tpl.id, feature, referenceAssetIds: sel.refs,
          modelId: sel.modelId || null, poses: sel.poses, scenes: sel.scenes,
          colors: sel.colors, count: sel.count, sizeId: sel.sizeId,
        },
      });
      this.setData({
        job: Object.assign({}, job, {
          items: (job.items || []).map((it) => Object.assign({}, it, { albumSelected: false })),
        }),
        stepKey: 'result',
        albumSelectedCount: 0,
        albumAllSelected: false,
      });
      this.poll();
    } catch (e) {
      wx.showToast({ title: e.message || '提交失败', icon: 'none' });
    } finally {
      this.setData({ submitting: false });
    }
  },
  async poll() {
    clearTimeout(this.timer);
    const j = this.data.job;
    if (!j || ['done', 'failed', 'partial', 'cancelled'].indexOf(j.status) >= 0) return;
    this.timer = setTimeout(async () => {
      try {
        // getJob 已兼容框架 jobId → 进度 / 结果图
        const job = await request({ url: `/api/products/${this.data.id}/promo/jobs/${j.id}` });
        this.setJobWithAlbum(job);
      } catch (e) { /* 继续重试 */ }
      this.poll();
    }, 3500);
  },
  previewResult(e) {
    const urls = this.data.job.items.filter((i) => i.url).map((i) => i.url);
    wx.previewImage({ urls, current: e.currentTarget.dataset.url });
  },
  toggleAlbumItem(e) {
    const idx = Number(e.currentTarget.dataset.index);
    const items = (this.data.job.items || []).slice();
    const it = items[idx];
    if (!it || !it.url) return;
    items[idx] = Object.assign({}, it, { albumSelected: !it.albumSelected });
    this.setData({ 'job.items': items });
    this.syncAlbumSel(items);
  },
  toggleSelectAllAlbum() {
    const items = (this.data.job.items || []).slice();
    const withUrl = items.filter((i) => i && i.url);
    const allOn = withUrl.length > 0 && withUrl.every((i) => i.albumSelected);
    const next = items.map((it) => (it && it.url
      ? Object.assign({}, it, { albumSelected: !allOn })
      : it));
    this.setData({ 'job.items': next });
    this.syncAlbumSel(next);
  },
  async saveToAlbum() {
    if (this.data.savingAlbum) return;
    const urls = ((this.data.job && this.data.job.items) || [])
      .filter((i) => i && i.url && i.albumSelected)
      .map((i) => i.url);
    if (!urls.length) {
      wx.showToast({ title: '请先选择要保存的图片', icon: 'none' });
      return;
    }
    this.setData({ savingAlbum: true });
    wx.showLoading({ title: `保存中 0/${urls.length}`, mask: true });
    try {
      const r = await saveUrlsToAlbum(urls, {
        onProgress(cur, total) {
          wx.showLoading({ title: `保存中 ${cur}/${total}`, mask: true });
        },
      });
      wx.hideLoading();
      const tip = r.fail
        ? `成功 ${r.ok} / 失败 ${r.fail}`
        : `已保存 ${r.ok} 张到相册`;
      wx.showToast({ title: tip, icon: 'none', duration: 2500 });
      if (r.fail && r.errors && r.errors[0]) {
        setTimeout(() => {
          wx.showModal({
            title: '部分保存失败',
            content: r.errors.slice(0, 3).join('\n'),
            showCancel: false,
          });
        }, 400);
      }
    } catch (e) {
      wx.hideLoading();
      wx.showToast({ title: (e && e.message) || '保存失败', icon: 'none' });
    } finally {
      this.setData({ savingAlbum: false });
    }
  },
  async saveAll() {
    this.setData({ saving: true });
    try {
      const r = await request({ url: `/api/products/${this.data.id}/promo/jobs/${this.data.job.id}/save`, method: 'POST', data: {} });
      this.setJobWithAlbum(r.job);
      wx.showToast({ title: r.added.length ? `已存入商品 ${r.added.length} 张` : '已全部保存过', icon: 'none' });
    } catch (e) {
      wx.showToast({ title: e.message || '保存失败', icon: 'none' });
    } finally {
      this.setData({ saving: false });
    }
  },
  copyCaption() {
    const text = (this.data.job && this.data.job.caption) || '';
    if (!text) {
      wx.showToast({ title: '文案生成后可复制', icon: 'none' });
      return;
    }
    wx.setClipboardData({
      data: text,
      success: () => wx.showToast({ title: '文案已复制', icon: 'none' }),
    });
  },
  goGallery() {
    wx.redirectTo({ url: `/pages/product/promo-gallery/promo-gallery?id=${this.data.id}` });
  },
  again() {
    this.setData({
      job: null, stepIdx: 0, stepKey: this.data.steps[0],
      albumSelectedCount: 0, albumAllSelected: false, savingAlbum: false,
    });
  },
});
